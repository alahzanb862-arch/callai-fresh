package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.ui.theme.AiViolet
import com.example.ui.theme.CallAcceptGreen
import com.example.ui.theme.CallEndRed
import com.example.ui.theme.CyanSpark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.ObsidianSurfaceElevated
import kotlin.math.sin

@Composable
fun UserAvatar(
    name: String,
    photoUrl: String? = null,
    size: Dp = 48.dp,
    isGroup: Boolean = false,
    online: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val initial = name.trim().firstOrNull()?.uppercase() ?: "؟"
    Box(modifier = modifier.size(size)) {
        if (!photoUrl.isNullOrBlank() && !isGroup) {
            AsyncImage(
                model = photoUrl,
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .border(1.5.dp, EmeraldGlow.copy(alpha = 0.45f), CircleShape),
            )
        } else {
            val gradient = if (isGroup) {
                Brush.linearGradient(listOf(CyanSpark.copy(alpha = 0.85f), AiViolet))
            } else {
                Brush.linearGradient(listOf(EmeraldGlow.copy(alpha = 0.85f), CyanSpark.copy(alpha = 0.85f)))
            }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(gradient),
            ) {
                if (isGroup) {
                    Icon(
                        imageVector = Icons.Filled.Group,
                        contentDescription = name,
                        tint = Color.White,
                        modifier = Modifier.size(size * 0.52f),
                    )
                } else {
                    Text(
                        text = initial,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF0B141A),
                    )
                }
            }
        }
        if (online && !isGroup) {
            Box(
                modifier = Modifier
                    .size(size * 0.26f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(EmeraldGlow)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
            )
        }
    }
}

@Composable
fun AiGlowBadge(
    label: String = "AI",
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.Transparent,
        modifier = modifier
            .background(
                brush = Brush.horizontalGradient(listOf(CyanSpark.copy(alpha = 0.25f), AiViolet.copy(alpha = 0.35f))),
                shape = RoundedCornerShape(50),
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(listOf(CyanSpark, AiViolet)),
                shape = RoundedCornerShape(50),
            ),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = CyanSpark,
                modifier = Modifier.size(14.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = CyanSpark,
            )
        }
    }
}

@Composable
fun VoiceWaveformVisualizer(
    micLevel: Float,
    isActive: Boolean,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "waveform")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1400),
            repeatMode = RepeatMode.Restart,
        ),
        label = "wavePhase",
    )

    Canvas(modifier = modifier) {
        val barCount = 24
        val spacing = size.width / (barCount * 2f - 1f)
        val barWidth = spacing
        val centerY = size.height / 2f
        val effectiveLevel = if (isActive) (0.18f + micLevel * 1.4f).coerceIn(0.18f, 1f) else 0.08f

        for (i in 0 until barCount) {
            val wave = (sin(phase + i * 0.45f) + 1f) * 0.5f
            val h = size.height * (0.15f + 0.85f * wave * effectiveLevel)
            val x = i * (barWidth + spacing)
            val color = if (i % 2 == 0) EmeraldGlow else CyanSpark
            drawRoundRect(
                color = color.copy(alpha = if (isActive) 0.9f else 0.35f),
                topLeft = Offset(x, centerY - h / 2f),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}

@Composable
fun IncomingCallBanner(
    call: CallSession,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = ObsidianSurfaceElevated,
        tonalElevation = 8.dp,
        shadowElevation = 12.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .border(1.5.dp, EmeraldGlow.copy(alpha = 0.6f), RoundedCornerShape(24.dp)),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(14.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                UserAvatar(name = call.callerName, size = 48.dp, online = true)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = call.callerName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (call.parsedMode == CallMode.VIDEO) Icons.Filled.Videocam else Icons.Filled.Call,
                            contentDescription = null,
                            tint = EmeraldGlow,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (call.parsedMode == CallMode.VIDEO) "مكالمة فيديو واردة..." else "مكالمة صوتية واردة...",
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldGlow,
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = onDecline,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(CallEndRed)
                        .testTag("decline_incoming_call_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.CallEnd,
                        contentDescription = "رفض المكالمة",
                        tint = Color.White,
                    )
                }
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = CallAcceptGreen),
                    shape = CircleShape,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("accept_incoming_call_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Call,
                        contentDescription = "رد",
                        tint = Color(0xFF0B141A),
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("رد", color = Color(0xFF0B141A), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
