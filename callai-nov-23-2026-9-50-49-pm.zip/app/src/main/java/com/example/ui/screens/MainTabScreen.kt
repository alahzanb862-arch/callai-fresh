package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.example.data.model.UiState
import com.example.ui.components.AiGlowBadge
import com.example.ui.components.UserAvatar
import com.example.ui.theme.CallAcceptGreen
import com.example.ui.theme.CallEndRed
import com.example.ui.theme.CyanSpark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceHigh
import java.text.SimpleDateFormat
import java.util.Locale

private data class HomeTab(
    val titleRes: Int,
    val icon: ImageVector,
    val tag: String,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTabScreen(
    myProfile: PrivateUser,
    contactsState: UiState<List<Contact>>,
    conversationsState: UiState<List<Conversation>>,
    callsState: UiState<List<CallSession>>,
    peerProfiles: Map<String, PublicProfile>,
    searchedProfile: PublicProfile?,
    isBusy: Boolean,
    feedbackMessage: String?,
    onClearFeedback: () -> Unit,
    onLookupUsername: (String) -> Unit,
    onClearSearchedProfile: () -> Unit,
    onAddContact: (username: String, nickname: String?, onDone: () -> Unit) -> Unit,
    onUpdateContactNickname: (contactUid: String, nickname: String) -> Unit,
    onDeleteContact: (contactUid: String) -> Unit,
    onOpenConversation: (conversationId: String) -> Unit,
    onOpenDirectChat: (targetUid: String, targetName: String) -> Unit,
    onCreateGroup: (title: String, desc: String?, memberUids: List<String>) -> Unit,
    onStartDirectCall: (targetUid: String, targetName: String, mode: CallMode) -> Unit,
    onStartGroupCall: (Conversation, CallMode) -> Unit,
    onUpdateProfile: (displayName: String, statusText: String?) -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onSignOut: () -> Unit,
    resolveDirectTitle: (Conversation, List<Contact>) -> String,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val tabs = remember {
        listOf(
            HomeTab(R.string.tab_chats, Icons.AutoMirrored.Filled.Chat, "tab_chats"),
            HomeTab(R.string.tab_calls, Icons.Filled.Call, "tab_calls"),
            HomeTab(R.string.tab_groups, Icons.Filled.Groups, "tab_groups"),
            HomeTab(R.string.tab_contacts, Icons.Filled.Contacts, "tab_contacts"),
        )
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    var showAddContactDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showQuickCallDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        if (!feedbackMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(feedbackMessage)
            onClearFeedback()
        }
    }

    val contacts = (contactsState as? UiState.Success)?.data ?: emptyList()
    val conversations = (conversationsState as? UiState.Success)?.data ?: emptyList()
    val calls = (callsState as? UiState.Success)?.data ?: emptyList()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = ObsidianBg,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianSurface),
                    title = {
                        if (searchVisible) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("ابحث في الدردشات وجهات الاتصال...") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_search_input"),
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "CallAI",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = EmeraldGlow,
                                )
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = ObsidianSurfaceHigh,
                                ) {
                                    Text(
                                        text = "@${myProfile.username}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyanSpark,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                searchVisible = !searchVisible
                                if (!searchVisible) searchQuery = ""
                            },
                            modifier = Modifier.testTag("toggle_search_button"),
                        ) {
                            Icon(
                                imageVector = if (searchVisible) Icons.Filled.Close else Icons.Filled.Search,
                                contentDescription = "بحث",
                            )
                        }
                        IconButton(
                            onClick = { showProfileDialog = true },
                            modifier = Modifier.testTag("profile_button"),
                        ) {
                            UserAvatar(
                                name = myProfile.displayName,
                                photoUrl = myProfile.photoUrl,
                                size = 34.dp,
                                online = true,
                            )
                        }
                    },
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        windowInsets = WindowInsets.navigationBars,
                    ) {
                        tabs.forEachIndexed { idx, tab ->
                            NavigationBarItem(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                icon = { Icon(tab.icon, contentDescription = stringResource(tab.titleRes)) },
                                label = { Text(stringResource(tab.titleRes), maxLines = 1) },
                                modifier = Modifier.testTag(tab.tag),
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        when (selectedTab) {
                            0 -> showAddContactDialog = true
                            1 -> showQuickCallDialog = true
                            2 -> showCreateGroupDialog = true
                            3 -> showAddContactDialog = true
                        }
                    },
                    containerColor = EmeraldGlow,
                    contentColor = ObsidianBg,
                    modifier = Modifier.testTag("home_fab"),
                ) {
                    val icon = when (selectedTab) {
                        1 -> Icons.Filled.Call
                        2 -> Icons.Filled.GroupAdd
                        3 -> Icons.Filled.PersonAdd
                        else -> Icons.Filled.Add
                    }
                    Icon(icon, contentDescription = "إجراء جديد")
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        Spacer(Modifier.height(12.dp))
                        tabs.forEachIndexed { idx, tab ->
                            NavigationRailItem(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                icon = { Icon(tab.icon, contentDescription = stringResource(tab.titleRes)) },
                                label = { Text(stringResource(tab.titleRes)) },
                                modifier = Modifier.testTag(tab.tag),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (selectedTab) {
                        0 -> ChatsTabContent(
                            myUid = myProfile.uid,
                            conversationsState = conversationsState,
                            contacts = contacts,
                            peerProfiles = peerProfiles,
                            searchQuery = searchQuery,
                            resolveTitle = resolveDirectTitle,
                            onOpenConversation = onOpenConversation,
                            onStartCall = { conv, mode ->
                                if (conv.conversationType == ConversationType.GROUP) {
                                    onStartGroupCall(conv, mode)
                                } else {
                                    val peerUid = conv.memberUids.firstOrNull { it != myProfile.uid } ?: return@ChatsTabContent
                                    onStartDirectCall(peerUid, resolveDirectTitle(conv, contacts), mode)
                                }
                            },
                            onAddFriendClick = { showAddContactDialog = true },
                        )

                        1 -> CallsTabContent(
                            myUid = myProfile.uid,
                            callsState = callsState,
                            onNewCallClick = { showQuickCallDialog = true },
                            onRedial = { call, mode ->
                                val otherUid = call.participantUids.firstOrNull { it != myProfile.uid }
                                if (otherUid != null) {
                                    val name = if (call.callerId == myProfile.uid) call.calleeName else call.callerName
                                    onStartDirectCall(otherUid, name, mode)
                                }
                            },
                        )

                        2 -> GroupsTabContent(
                            groups = conversations.filter { it.conversationType == ConversationType.GROUP },
                            searchQuery = searchQuery,
                            onOpenGroup = onOpenConversation,
                            onCallGroup = onStartGroupCall,
                            onCreateGroupClick = { showCreateGroupDialog = true },
                        )

                        3 -> ContactsTabContent(
                            contactsState = contactsState,
                            searchQuery = searchQuery,
                            onAddContactClick = { showAddContactDialog = true },
                            onMessageContact = { contact ->
                                onOpenDirectChat(contact.contactUid, contact.nickname ?: contact.displayName)
                            },
                            onCallContact = { contact, mode ->
                                onStartDirectCall(contact.contactUid, contact.nickname ?: contact.displayName, mode)
                            },
                            onUpdateNickname = onUpdateContactNickname,
                            onDeleteContact = onDeleteContact,
                        )
                    }
                }
            }
        }
    }

    if (showAddContactDialog) {
        AddContactByUsernameDialog(
            isBusy = isBusy,
            searchedProfile = searchedProfile,
            onLookup = onLookupUsername,
            onDismiss = {
                onClearSearchedProfile()
                showAddContactDialog = false
            },
            onConfirmAdd = { username, nickname ->
                onAddContact(username, nickname) {
                    showAddContactDialog = false
                }
            },
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            contacts = contacts,
            isBusy = isBusy,
            onDismiss = { showCreateGroupDialog = false },
            onCreate = { title, desc, memberUids ->
                onCreateGroup(title, desc, memberUids)
                showCreateGroupDialog = false
            },
        )
    }

    if (showQuickCallDialog) {
        QuickCallDialog(
            contacts = contacts,
            onDismiss = { showQuickCallDialog = false },
            onCallContact = { contact, mode ->
                showQuickCallDialog = false
                onStartDirectCall(contact.contactUid, contact.nickname ?: contact.displayName, mode)
            },
        )
    }

    if (showProfileDialog) {
        val notificationsEnabled = com.example.notifications.CallNotificationManager.hasNotificationPermission(context)
        ProfileSettingsDialog(
            user = myProfile,
            isBusy = isBusy,
            notificationsEnabled = notificationsEnabled,
            onRequestNotificationPermission = onRequestNotificationPermission,
            onTestNotification = {
                com.example.notifications.CallNotificationManager.showNewMessageNotification(
                    context = context,
                    conversationId = "test_preview",
                    chatTitle = "CallAI",
                    senderName = "مساعد CallAI",
                    messageText = "الإشعارات تعمل بنجاح! ستصلك تنبيهات المكالمات والرسائل فوراً.",
                )
            },
            onDismiss = { showProfileDialog = false },
            onSave = { name, status ->
                onUpdateProfile(name, status)
                showProfileDialog = false
            },
            onSignOut = {
                showProfileDialog = false
                onSignOut()
            },
        )
    }
}

@Composable
private fun ChatsTabContent(
    myUid: String,
    conversationsState: UiState<List<Conversation>>,
    contacts: List<Contact>,
    peerProfiles: Map<String, PublicProfile>,
    searchQuery: String,
    resolveTitle: (Conversation, List<Contact>) -> String,
    onOpenConversation: (String) -> Unit,
    onStartCall: (Conversation, CallMode) -> Unit,
    onAddFriendClick: () -> Unit,
) {
    when (conversationsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldGlow)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(conversationsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val filtered = conversationsState.data.filter { conv ->
                val title = resolveTitle(conv, contacts)
                searchQuery.isBlank() || title.contains(searchQuery, ignoreCase = true) ||
                    (conv.lastMessageText?.contains(searchQuery, ignoreCase = true) == true)
            }
            if (filtered.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Filled.ChatBubbleOutline,
                    title = "لا توجد محادثات بعد",
                    subtitle = "أضف صديقاً عبر اسم المستخدم (@username) لتبدأ الدردشة أو المكالمة مع مساعد AI.",
                    actionLabel = "إضافة صديق بـ @username",
                    onAction = onAddFriendClick,
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(vertical = 8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(filtered, key = { it.id }) { conv ->
                        val title = resolveTitle(conv, contacts)
                        val otherUid = conv.memberUids.firstOrNull { it != myUid }
                        val photo = otherUid?.let { uid ->
                            contacts.firstOrNull { it.contactUid == uid }?.photoUrl ?: peerProfiles[uid]?.photoUrl
                        }
                        val timeStr = (conv.lastMessageAt ?: conv.updatedAt)?.toDate()?.let {
                            SimpleDateFormat("HH:mm", Locale.getDefault()).format(it)
                        } ?: ""

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenConversation(conv.id) }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .testTag("conversation_item_${conv.id}"),
                        ) {
                            UserAvatar(
                                name = title,
                                photoUrl = photo,
                                size = 52.dp,
                                isGroup = conv.conversationType == ConversationType.GROUP,
                            )
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Text(
                                        text = timeStr,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = conv.lastMessageText ?: "ابدأ المحادثة الآن...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Spacer(Modifier.width(4.dp))
                            IconButton(
                                onClick = { onStartCall(conv, CallMode.AUDIO) },
                                modifier = Modifier.size(44.dp),
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = "مكالمة صوتية", tint = EmeraldGlow)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallsTabContent(
    myUid: String,
    callsState: UiState<List<CallSession>>,
    onNewCallClick: () -> Unit,
    onRedial: (CallSession, CallMode) -> Unit,
) {
    when (callsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldGlow)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(callsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            if (callsState.data.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Filled.Call,
                    title = "سجل المكالمات فارغ",
                    subtitle = "ابدأ مكالمة صوتية أو مرئية مع صديق واضغط زر AI في أي لحظة ليساعدك.",
                    actionLabel = "بدء مكالمة جديدة",
                    onAction = onNewCallClick,
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(callsState.data, key = { it.id }) { call ->
                        val isOutgoing = call.callerId == myUid
                        val peerName = if (isOutgoing) call.calleeName else call.callerName
                        val dateText = call.createdAt?.toDate()?.let {
                            SimpleDateFormat("dd MMM • HH:mm", Locale.getDefault()).format(it)
                        } ?: ""
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceHigh),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    UserAvatar(name = peerName, size = 46.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = peerName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isOutgoing) Icons.Filled.CallMade else Icons.Filled.CallReceived,
                                                contentDescription = null,
                                                tint = if (call.parsedStatus == CallStatus.DECLINED) CallEndRed else CallAcceptGreen,
                                                modifier = Modifier.size(14.dp),
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            val statusLabel = when (call.parsedStatus) {
                                                CallStatus.RINGING -> "جاري الرنين"
                                                CallStatus.ACTIVE -> "مكالمة جارية"
                                                CallStatus.DECLINED -> "مرفوضة"
                                                CallStatus.ENDED -> "مكتملة"
                                            }
                                            Text(
                                                text = "$statusLabel • $dateText",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                    IconButton(onClick = { onRedial(call, CallMode.AUDIO) }) {
                                        Icon(Icons.Filled.Call, contentDescription = "اتصال صوتي", tint = EmeraldGlow)
                                    }
                                    IconButton(onClick = { onRedial(call, CallMode.VIDEO) }) {
                                        Icon(Icons.Filled.Videocam, contentDescription = "اتصال فيديو", tint = CyanSpark)
                                    }
                                }
                                if (call.aiActive && !call.lastAiPrompt.isNullOrBlank()) {
                                    Spacer(Modifier.height(10.dp))
                                    Surface(
                                        color = ObsidianBg.copy(alpha = 0.7f),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(10.dp),
                                        ) {
                                            Icon(
                                                Icons.Filled.AutoAwesome,
                                                contentDescription = null,
                                                tint = CyanSpark,
                                                modifier = Modifier.size(16.dp),
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                text = "AI في المكالمة: ${call.lastAiPrompt}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = CyanSpark,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupsTabContent(
    groups: List<Conversation>,
    searchQuery: String,
    onOpenGroup: (String) -> Unit,
    onCallGroup: (Conversation, CallMode) -> Unit,
    onCreateGroupClick: () -> Unit,
) {
    val filtered = groups.filter {
        searchQuery.isBlank() || it.title.contains(searchQuery, ignoreCase = true)
    }
    if (filtered.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Filled.Groups,
            title = "لا توجد مجموعات بعد",
            subtitle = "أنشئ مجموعة لأصدقائك أو فريقك وشارك معهم الدردشة والمكالمات ومساعد AI.",
            actionLabel = "إنشاء مجموعة جديدة",
            onAction = onCreateGroupClick,
        )
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(filtered, key = { it.id }) { group ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceHigh),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenGroup(group.id) }
                        .testTag("group_card_${group.id}"),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp),
                    ) {
                        UserAvatar(name = group.title, size = 50.dp, isGroup = true)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = group.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = "${group.memberUids.size} أعضاء • ${group.lastMessageText ?: group.description ?: "مجموعة نشطة"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { onCallGroup(group, CallMode.AUDIO) }) {
                            Icon(Icons.Filled.Call, contentDescription = "مكالمة جماعية", tint = EmeraldGlow)
                        }
                        IconButton(onClick = { onCallGroup(group, CallMode.VIDEO) }) {
                            Icon(Icons.Filled.Videocam, contentDescription = "مكالمة فيديو جماعية", tint = CyanSpark)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactsTabContent(
    contactsState: UiState<List<Contact>>,
    searchQuery: String,
    onAddContactClick: () -> Unit,
    onMessageContact: (Contact) -> Unit,
    onCallContact: (Contact, CallMode) -> Unit,
    onUpdateNickname: (contactUid: String, nickname: String) -> Unit,
    onDeleteContact: (contactUid: String) -> Unit,
) {
    var editingContact by remember { mutableStateOf<Contact?>(null) }

    when (contactsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldGlow)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(contactsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val filtered = contactsState.data.filter { contact ->
                searchQuery.isBlank() ||
                    contact.displayName.contains(searchQuery, ignoreCase = true) ||
                    contact.username.contains(searchQuery, ignoreCase = true) ||
                    (contact.nickname?.contains(searchQuery, ignoreCase = true) == true)
            }
            if (filtered.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Filled.Contacts,
                    title = "قائمة جهات الاتصال فارغة",
                    subtitle = "ابحث عن أصدقائك باسم المستخدم (@username) وأضفهم إلى جهات اتصالك.",
                    actionLabel = "إضافة جهة اتصال",
                    onAction = onAddContactClick,
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(filtered, key = { it.contactUid }) { contact ->
                        val title = contact.nickname?.takeIf { it.isNotBlank() } ?: contact.displayName
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceHigh),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp),
                            ) {
                                UserAvatar(name = title, photoUrl = contact.photoUrl, size = 48.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    Text(
                                        text = "@${contact.username}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyanSpark,
                                    )
                                }
                                IconButton(onClick = { onMessageContact(contact) }) {
                                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "مراسلة", tint = MaterialTheme.colorScheme.onSurface)
                                }
                                IconButton(onClick = { onCallContact(contact, CallMode.AUDIO) }) {
                                    Icon(Icons.Filled.Call, contentDescription = "اتصال صوتي", tint = EmeraldGlow)
                                }
                                IconButton(onClick = { onCallContact(contact, CallMode.VIDEO) }) {
                                    Icon(Icons.Filled.Videocam, contentDescription = "اتصال فيديو", tint = CyanSpark)
                                }
                                IconButton(onClick = { editingContact = contact }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingContact?.let { target ->
        var nickname by remember(target.contactUid) { mutableStateOf(target.nickname ?: target.displayName) }
        AlertDialog(
            onDismissRequest = { editingContact = null },
            title = { Text("تعديل جهة الاتصال @${target.username}") },
            text = {
                OutlinedTextField(
                    value = nickname,
                    onValueChange = { nickname = it.take(80) },
                    label = { Text("الاسم المستعار") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateNickname(target.contactUid, nickname)
                        editingContact = null
                    },
                ) { Text("حفظ") }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            onDeleteContact(target.contactUid)
                            editingContact = null
                        },
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = CallEndRed)
                        Spacer(Modifier.width(4.dp))
                        Text("حذف", color = CallEndRed)
                    }
                    TextButton(onClick = { editingContact = null }) { Text("إلغاء") }
                }
            },
        )
    }
}

@Composable
private fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit,
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(EmeraldGlow.copy(alpha = 0.14f)),
            ) {
                Icon(icon, contentDescription = null, tint = EmeraldGlow, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGlow, contentColor = ObsidianBg),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text(actionLabel, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AddContactByUsernameDialog(
    isBusy: Boolean,
    searchedProfile: PublicProfile?,
    onLookup: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmAdd: (username: String, nickname: String?) -> Unit,
) {
    var usernameQuery by remember { mutableStateOf("") }
    var nickname by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة جهة اتصال") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = usernameQuery,
                    onValueChange = { usernameQuery = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' || c == '@' } },
                    label = { Text("اسم المستخدم (@username)") },
                    leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_username_input"),
                )
                OutlinedButton(
                    onClick = { onLookup(usernameQuery) },
                    enabled = !isBusy && usernameQuery.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lookup_username_button"),
                ) {
                    Text(if (isBusy) "جاري البحث..." else "بحث عن المستخدم")
                }

                if (searchedProfile != null) {
                    Surface(
                        color = ObsidianSurfaceHigh,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(10.dp),
                        ) {
                            UserAvatar(name = searchedProfile.displayName, photoUrl = searchedProfile.photoUrl, size = 40.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(searchedProfile.displayName, style = MaterialTheme.typography.labelLarge)
                                Text("@${searchedProfile.username}", style = MaterialTheme.typography.labelSmall, color = CyanSpark)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = nickname,
                        onValueChange = { nickname = it.take(80) },
                        label = { Text("اسم مخصص (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmAdd(usernameQuery, nickname.ifBlank { null }) },
                enabled = !isBusy && usernameQuery.removePrefix("@").length >= 3,
                modifier = Modifier.testTag("confirm_add_contact_button"),
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
    )
}

@Composable
private fun CreateGroupDialog(
    contacts: List<Contact>,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onCreate: (title: String, desc: String?, memberUids: List<String>) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val selectedUids = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إنشاء مجموعة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(80) },
                    label = { Text("اسم المجموعة") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_title_input"),
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it.take(240) },
                    label = { Text("وصف المجموعة (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("اختر الأعضاء من جهات الاتصال:", style = MaterialTheme.typography.labelLarge)
                if (contacts.isEmpty()) {
                    Text(
                        "يمكنك إنشاء المجموعة الآن وإضافة الأعضاء لاحقاً من جهات الاتصال.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(160.dp)) {
                        items(contacts, key = { it.contactUid }) { c ->
                            val checked = selectedUids.contains(c.contactUid)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (checked) selectedUids.remove(c.contactUid)
                                        else selectedUids.add(c.contactUid)
                                    }
                                    .padding(vertical = 4.dp),
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { isChecked ->
                                        if (isChecked) selectedUids.add(c.contactUid)
                                        else selectedUids.remove(c.contactUid)
                                    },
                                )
                                Text("${c.nickname ?: c.displayName} (@${c.username})")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(title, description.ifBlank { null }, selectedUids.toList()) },
                enabled = !isBusy && title.isNotBlank(),
                modifier = Modifier.testTag("confirm_create_group_button"),
            ) {
                Text("إنشاء")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}

@Composable
private fun QuickCallDialog(
    contacts: List<Contact>,
    onDismiss: () -> Unit,
    onCallContact: (Contact, CallMode) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بدء مكالمة مع AI") },
        text = {
            if (contacts.isEmpty()) {
                Text("أضف جهة اتصال أولاً عبر @username لتتمكن من الاتصال بها.")
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(240.dp),
                ) {
                    items(contacts, key = { it.contactUid }) { contact ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            UserAvatar(name = contact.displayName, photoUrl = contact.photoUrl, size = 38.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contact.nickname ?: contact.displayName, style = MaterialTheme.typography.labelLarge)
                                Text("@${contact.username}", style = MaterialTheme.typography.labelSmall, color = CyanSpark)
                            }
                            IconButton(onClick = { onCallContact(contact, CallMode.AUDIO) }) {
                                Icon(Icons.Filled.Call, contentDescription = "صوت", tint = EmeraldGlow)
                            }
                            IconButton(onClick = { onCallContact(contact, CallMode.VIDEO) }) {
                                Icon(Icons.Filled.Videocam, contentDescription = "فيديو", tint = CyanSpark)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
    )
}

@Composable
private fun ProfileSettingsDialog(
    user: PrivateUser,
    isBusy: Boolean,
    notificationsEnabled: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onTestNotification: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (displayName: String, statusText: String?) -> Unit,
    onSignOut: () -> Unit,
) {
    var displayName by remember(user.uid) { mutableStateOf(user.displayName) }
    var statusText by remember(user.uid) { mutableStateOf(user.statusText ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(name = user.displayName, photoUrl = user.photoUrl, size = 40.dp, online = true)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("@${user.username}", style = MaterialTheme.typography.titleMedium, color = CyanSpark)
                    Text(user.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it.take(80) },
                    label = { Text("الاسم المعروض") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = statusText,
                    onValueChange = { statusText = it.take(160) },
                    label = { Text("الحالة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(
                    onClick = {
                        if (notificationsEnabled) onTestNotification()
                        else onRequestNotificationPermission()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("notification_settings_button"),
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = EmeraldGlow)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (notificationsEnabled) "اختبار إشعار المكالمات والرسائل" else "تفعيل إذن الإشعارات",
                    )
                }
                AiGlowBadge(label = "حساب Google موثق")
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(displayName, statusText) },
                enabled = !isBusy && displayName.isNotBlank(),
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            Row {
                TextButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("sign_out_button"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = CallEndRed)
                    Spacer(Modifier.width(4.dp))
                    Text("خروج", color = CallEndRed)
                }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        },
    )
}
