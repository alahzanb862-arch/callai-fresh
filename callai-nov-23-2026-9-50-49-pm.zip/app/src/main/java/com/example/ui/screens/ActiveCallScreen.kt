package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.CallAudioEngine
import com.example.data.model.CallEvent
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.PrivateUser
import com.example.data.model.UiState
import com.example.ui.components.AiGlowBadge
import com.example.ui.components.UserAvatar
import com.example.ui.components.VoiceWaveformVisualizer
import com.example.ui.theme.AiViolet
import com.example.ui.theme.CallEndRed
import com.example.ui.theme.CyanSpark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHigh
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.viewmodel.ActiveCallViewModel
import com.example.viewmodel.AiUiState
import kotlinx.coroutines.delay

@Composable
fun ActiveCallScreen(
    myProfile: PrivateUser,
    viewModel: ActiveCallViewModel,
    onCallClosed: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioEngine = remember(context) { CallAudioEngine(context) }

    val callState by viewModel.callState.collectAsStateWithLifecycle()
    val events by viewModel.eventsState.collectAsStateWithLifecycle()
    val aiState by viewModel.aiState.collectAsStateWithLifecycle()
    val shareAiWithFriend by viewModel.shareAiWithFriend.collectAsStateWithLifecycle()
    val speakAiAloud by viewModel.speakAiAloud.collectAsStateWithLifecycle()

    val micLevel by audioEngine.micLevel.collectAsStateWithLifecycle()
    val isRecordingVoiceAi by audioEngine.isRecordingVoiceCommand.collectAsStateWithLifecycle()

    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var useFrontCamera by remember { mutableStateOf(true) }
    var showAiOverlay by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableIntStateOf(0) }

    var hasAudioPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        hasAudioPerm = result[Manifest.permission.RECORD_AUDIO] ?: hasAudioPerm
        hasCameraPerm = result[Manifest.permission.CAMERA] ?: hasCameraPerm
        if (hasAudioPerm) {
            audioEngine.startMicMonitor(scope)
        }
    }

    val callSession: CallSession? = (callState as? UiState.Success)?.data
    val callMode = callSession?.parsedMode ?: CallMode.AUDIO
    val callStatus = callSession?.parsedStatus ?: CallStatus.RINGING

    LaunchedEffect(Unit) {
        val needed = buildList {
            if (!hasAudioPerm) add(Manifest.permission.RECORD_AUDIO)
            if (!hasCameraPerm) add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) {
            permLauncher.launch(needed.toTypedArray())
        } else {
            audioEngine.startMicMonitor(scope)
        }
    }

    LaunchedEffect(isSpeakerOn, isMuted) {
        audioEngine.configureCallAudio(speakerOn = isSpeakerOn, muted = isMuted)
    }

    DisposableEffect(audioEngine) {
        onDispose { audioEngine.release() }
    }

    LaunchedEffect(callStatus) {
        if (callStatus == CallStatus.ACTIVE) {
            while (true) {
                delay(1000L)
                elapsedSeconds++
            }
        } else if (callStatus == CallStatus.ENDED || callStatus == CallStatus.DECLINED) {
            delay(800L)
            onCallClosed()
        }
    }

    val peerTitle = remember(callSession, myProfile.uid) {
        if (callSession == null) "مكالمة CallAI"
        else if (callSession.callerId == myProfile.uid) callSession.calleeName
        else callSession.callerName
    }

    val formattedTime = remember(elapsedSeconds) {
        val m = elapsedSeconds / 60
        val s = elapsedSeconds % 60
        "%02d:%02d".format(m, s)
    }

    Scaffold(containerColor = ObsidianBg) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            // Video background via CameraX when VIDEO mode & permission granted
            if (callMode == CallMode.VIDEO && hasCameraPerm) {
                CameraXCallPreview(
                    useFrontCamera = useFrontCamera,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    ObsidianBg.copy(alpha = 0.72f),
                                    Color.Transparent,
                                    ObsidianBg.copy(alpha = 0.88f),
                                ),
                            ),
                        ),
                )
            } else {
                // Atmospheric radial gradient for Audio Call
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    EmeraldGlow.copy(alpha = 0.16f),
                                    CyanSpark.copy(alpha = 0.08f),
                                    ObsidianBg,
                                ),
                            ),
                        ),
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxSize()
                    .safeDrawingPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                // TOP HEADER
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AiGlowBadge(
                        label = if (callMode == CallMode.VIDEO) "مكالمة فيديو + AI" else "مكالمة صوتية + AI",
                    )
                    Spacer(Modifier.height(14.dp))
                    if (callMode == CallMode.AUDIO || !hasCameraPerm) {
                        UserAvatar(name = peerTitle, size = 96.dp, online = callStatus == CallStatus.ACTIVE)
                        Spacer(Modifier.height(14.dp))
                    }
                    Text(
                        text = peerTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = when (callStatus) {
                            CallStatus.RINGING -> "جاري الرنين... يمكنك تجربة AI فوراً"
                            CallStatus.ACTIVE -> formattedTime
                            CallStatus.DECLINED -> "تم رفض المكالمة"
                            CallStatus.ENDED -> "انتهت المكالمة"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = SpaceGroteskFontFamily),
                        color = EmeraldGlow,
                    )
                }

                // MIDDLE: Live Mic Waveform + Shared In-Call AI Feed
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                ) {
                    if (callMode == CallMode.AUDIO) {
                        VoiceWaveformVisualizer(
                            micLevel = micLevel,
                            isActive = !isMuted && hasAudioPerm,
                            modifier = Modifier
                                .fillMaxWidth(0.82f)
                                .height(68.dp),
                        )
                        Spacer(Modifier.height(16.dp))
                    }

                    // Live Shared AI Answers visible to both friends in the call
                    if (events.isNotEmpty()) {
                        Surface(
                            color = ObsidianSurfaceElevated.copy(alpha = 0.88f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CyanSpark.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
                        ) {
                            LazyColumn(
                                contentPadding = PaddingValues(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.height(150.dp),
                            ) {
                                items(events.takeLast(5), key = { it.id }) { evt ->
                                    SharedCallEventRow(evt)
                                }
                            }
                        }
                    }
                }

                // BOTTOM CALL CONTROLS + CENTER GLOWING AI BUTTON
                Surface(
                    color = ObsidianSurface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(30.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(30.dp)),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 8.dp),
                    ) {
                        // Mute Mic
                        CallControlIcon(
                            icon = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                            label = if (isMuted) "مكتوم" else "الميكروفون",
                            active = isMuted,
                            onClick = { isMuted = !isMuted },
                            tag = "call_mute_button",
                        )

                        // Speakerphone
                        CallControlIcon(
                            icon = Icons.Filled.VolumeUp,
                            label = "مكبر",
                            active = isSpeakerOn,
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            tag = "call_speaker_button",
                        )

                        // CENTER PROMINENT AI BUTTON
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(CyanSpark, AiViolet)))
                                    .clickable { showAiOverlay = true }
                                    .testTag("in_call_ai_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "تشغيل مساعد AI في المكالمة",
                                    tint = Color.White,
                                    modifier = Modifier.size(30.dp),
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "مساعد AI",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanSpark,
                            )
                        }

                        // Video / Camera Switch
                        if (callMode == CallMode.VIDEO) {
                            CallControlIcon(
                                icon = Icons.Filled.Cameraswitch,
                                label = "الكاميرا",
                                active = false,
                                onClick = { useFrontCamera = !useFrontCamera },
                                tag = "call_flip_camera_button",
                            )
                        } else {
                            CallControlIcon(
                                icon = if (callMode == CallMode.VIDEO) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                                label = "فيديو",
                                active = false,
                                onClick = { viewModel.toggleVideoMode(callMode) },
                                tag = "call_toggle_video_button",
                            )
                        }

                        // Hang Up
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {
                                    viewModel.endCall()
                                    onCallClosed()
                                },
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(CallEndRed)
                                    .testTag("end_call_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CallEnd,
                                    contentDescription = "إنهاء المكالمة",
                                    tint = Color.White,
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text("إنهاء", style = MaterialTheme.typography.labelSmall, color = CallEndRed)
                        }
                    }
                }
            }

            // IN-CALL AI CO-PILOT OVERLAY
            AnimatedVisibility(
                visible = showAiOverlay,
                modifier = Modifier.align(Alignment.BottomCenter),
            ) {
                InCallAiCoPilotOverlay(
                    friendName = peerTitle,
                    aiState = aiState,
                    isRecordingVoice = isRecordingVoiceAi,
                    shareWithFriend = shareAiWithFriend,
                    speakAloud = speakAiAloud,
                    onShareWithFriendChanged = viewModel::setShareAiWithFriend,
                    onSpeakAloudChanged = viewModel::setSpeakAiAloud,
                    onAskText = { prompt ->
                        viewModel.askAiInCallText(prompt, myProfile) { answer ->
                            if (speakAiAloud) audioEngine.speakText(answer)
                        }
                    },
                    onToggleVoiceCapture = {
                        if (!hasAudioPerm) {
                            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                        } else if (!isRecordingVoiceAi) {
                            audioEngine.startVoiceCommandCapture()
                        } else {
                            val wav = audioEngine.stopVoiceCommandCaptureAsWav()
                            if (wav != null) {
                                viewModel.askAiInCallVoice(wav, myProfile) { answer ->
                                    if (speakAiAloud) audioEngine.speakText(answer)
                                }
                            }
                        }
                    },
                    onSpeakNow = { text -> audioEngine.speakText(text) },
                    onClose = {
                        if (isRecordingVoiceAi) audioEngine.stopVoiceCommandCaptureAsWav()
                        showAiOverlay = false
                    },
                )
            }
        }
    }
}

@Composable
private fun CameraXCallPreview(
    useFrontCamera: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }

    LaunchedEffect(useFrontCamera) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener(
            {
                try {
                    val provider = providerFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    val selector = if (useFrontCamera) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, selector, preview)
                } catch (e: Exception) {
                    Log.w("CameraXCall", "Camera bind warning: ${e.message}")
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier,
    )
}

@Composable
private fun CallControlIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    tag: String,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(if (active) EmeraldGlow.copy(alpha = 0.25f) else ObsidianSurfaceHigh)
                .testTag(tag),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) EmeraldGlow else Color.White,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SharedCallEventRow(event: CallEvent) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianBg.copy(alpha = 0.65f))
            .padding(10.dp),
    ) {
        Text(
            text = "✨ AI (${event.senderName})",
            style = MaterialTheme.typography.labelMedium,
            color = CyanSpark,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = event.content,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun InCallAiCoPilotOverlay(
    friendName: String,
    aiState: AiUiState,
    isRecordingVoice: Boolean,
    shareWithFriend: Boolean,
    speakAloud: Boolean,
    onShareWithFriendChanged: (Boolean) -> Unit,
    onSpeakAloudChanged: (Boolean) -> Unit,
    onAskText: (String) -> Unit,
    onToggleVoiceCapture: () -> Unit,
    onSpeakNow: (String) -> Unit,
    onClose: () -> Unit,
) {
    var prompt by remember { mutableStateOf("") }
    val quickActions = remember {
        listOf(
            "حل هذا السؤال خطوة بخطوة",
            "لخّص ما ناقشناه حتى الآن",
            "ترجم كلامنا للإنجليزية",
            "اقترح 3 أفكار سريعة",
        )
    }

    Surface(
        color = ObsidianSurfaceElevated,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 12.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .border(
                1.5.dp,
                Brush.horizontalGradient(listOf(CyanSpark, AiViolet)),
                RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            ),
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(18.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                AiGlowBadge("مساعد AI أثناء مكالمتك مع $friendName")
                IconButton(onClick = onClose, modifier = Modifier.testTag("close_in_call_ai_button")) {
                    Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = Color.White)
                }
            }

            // Voice-first AI ask button
            Surface(
                color = if (isRecordingVoice) CallEndRed.copy(alpha = 0.2f) else EmeraldGlow.copy(alpha = 0.14f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleVoiceCapture() }
                    .testTag("in_call_voice_ai_button"),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 14.dp),
                ) {
                    Icon(
                        imageVector = if (isRecordingVoice) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = null,
                        tint = if (isRecordingVoice) CallEndRed else EmeraldGlow,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (isRecordingVoice) "اضغط لإيقاف وإرسال صوتك إلى AI" else "اضغط وتحدث بصوتك لـ AI الآن",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isRecordingVoice) CallEndRed else EmeraldGlow,
                    )
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickActions) { chipText ->
                    AssistChip(
                        onClick = { onAskText(chipText) },
                        label = { Text(chipText) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = ObsidianSurfaceHigh),
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it.take(1000) },
                    placeholder = { Text("اكتب أي سؤال ليحله AI لكما...") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("in_call_ai_input"),
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val p = prompt
                        prompt = ""
                        onAskText(p)
                    },
                    enabled = prompt.isNotBlank(),
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (prompt.isNotBlank()) CyanSpark else ObsidianSurfaceHigh)
                        .testTag("in_call_ai_send_button"),
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = "إرسال",
                        tint = if (prompt.isNotBlank()) ObsidianBg else Color.Gray,
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = shareWithFriend, onCheckedChange = onShareWithFriendChanged)
                    Spacer(Modifier.width(6.dp))
                    Text("مشاركة مع صديقي", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = speakAloud, onCheckedChange = onSpeakAloudChanged)
                    Spacer(Modifier.width(6.dp))
                    Text("قراءة صوتية", style = MaterialTheme.typography.bodySmall)
                }
            }

            when (aiState) {
                is AiUiState.Idle -> Unit
                is AiUiState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyanSpark, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("AI يحلل ويجيب...", color = CyanSpark)
                }
                is AiUiState.Streaming -> Surface(
                    color = ObsidianBg,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(aiState.text, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
                is AiUiState.Success -> Surface(
                    color = ObsidianBg,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(aiState.text, style = MaterialTheme.typography.bodyMedium)
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            IconButton(onClick = { onSpeakNow(aiState.text) }) {
                                Icon(Icons.Filled.VolumeUp, contentDescription = "تشغيل الصوت", tint = EmeraldGlow)
                            }
                        }
                    }
                }
                is AiUiState.Error -> Text(aiState.message, color = CallEndRed)
            }
        }
    }
}
