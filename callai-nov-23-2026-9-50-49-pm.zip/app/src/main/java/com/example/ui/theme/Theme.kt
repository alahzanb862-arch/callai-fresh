package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val CallAIDarkColorScheme = darkColorScheme(
    primary = EmeraldGlow,
    onPrimary = ObsidianBg,
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = EmeraldGlow,
    secondary = CyanSpark,
    onSecondary = ObsidianBg,
    secondaryContainer = CyanContainerDark,
    onSecondaryContainer = CyanSpark,
    tertiary = AiViolet,
    onTertiary = Color.White,
    background = ObsidianBg,
    onBackground = TextPrimaryDark,
    surface = ObsidianSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ObsidianSurfaceHigh,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainer = ObsidianSurfaceHigh,
    surfaceContainerHigh = ObsidianSurfaceElevated,
    outline = ObsidianOutline,
    error = CallEndRed,
    onError = Color.White,
)

private val CallAILightColorScheme = lightColorScheme(
    primary = EmeraldLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0F5E5),
    onPrimaryContainer = Color(0xFF003823),
    secondary = CyanLightSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1F3F7),
    onSecondaryContainer = Color(0xFF00363D),
    tertiary = AiViolet,
    onTertiary = Color.White,
    background = LightBg,
    onBackground = Color(0xFF111B21),
    surface = LightSurface,
    onSurface = Color(0xFF111B21),
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = Color(0xFF54656F),
    surfaceContainer = LightSurfaceHigh,
    outline = Color(0xFFD4DFDA),
    error = CallEndRed,
    onError = Color.White,
)

val CallAIShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun CallAITheme(
    darkTheme: Boolean = true, // Sleek Obsidian Dark default matching luxury call/chat aesthetic
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) CallAIDarkColorScheme else CallAILightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        LaunchedEffect(darkTheme) {
            val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CallAITypography,
        shapes = CallAIShapes,
        content = content,
    )
}
