package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.example.R
import com.example.data.repository.AuthProfileRepository
import com.example.data.repository.attemptAutoSignIn
import com.example.data.repository.onGoogleSignInClicked
import com.example.ui.components.AiGlowBadge
import com.example.ui.theme.CyanSpark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurfaceHigh
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isLoading by remember { mutableStateOf(false) }
    var isCheckingSilent by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        withFrameNanos { }
        delay(250)
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isCheckingSilent = false
                onAuthSuccess()
            },
            onUnauthenticated = {
                isCheckingSilent = false
            },
            scope = scope,
        )
    }

    Scaffold(
        containerColor = ObsidianBg,
    ) { innerPadding ->
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState()),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 520.dp)
                    .padding(horizontal = 24.dp, vertical = 20.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                ) {
                    AsyncImage(
                        model = R.drawable.callai_app_icon_1795355982101,
                        contentDescription = "أيقونة CallAI",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, EmeraldGlow.copy(alpha = 0.55f), RoundedCornerShape(12.dp)),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }

                // Hero Artwork Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .border(
                            1.dp,
                            Brush.horizontalGradient(listOf(EmeraldGlow.copy(alpha = 0.5f), CyanSpark.copy(alpha = 0.5f))),
                            RoundedCornerShape(28.dp),
                        ),
                ) {
                    AsyncImage(
                        model = R.drawable.img_callai_hero,
                        contentDescription = "CallAI Hero",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.85f)),
                                ),
                            ),
                    )
                    AiGlowBadge(
                        label = "CallAI Co-Pilot",
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(14.dp),
                    )
                }

                Spacer(Modifier.height(24.dp))

                Text(
                    text = stringResource(R.string.welcome_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = stringResource(R.string.welcome_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )

                Spacer(Modifier.height(22.dp))

                // Feature Highlights
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    FeaturePill(
                        icon = Icons.Filled.AutoAwesome,
                        title = "مساعد AI أثناء المكالمة والدردشة",
                        subtitle = "اضغط زر AI أو تحدث بصوتك ليحل ويلخص ويجيب فوراً",
                    )
                    FeaturePill(
                        icon = Icons.Filled.Call,
                        title = "مكالمات صوتية ومرئية + مجموعات",
                        subtitle = "تواصل مع أصدقائك وجهات اتصالك ومجموعاتك بسلاسة",
                    )
                    FeaturePill(
                        icon = Icons.Filled.VerifiedUser,
                        title = "حساب Google حقيقي واسم مستخدم",
                        subtitle = "هوية موثقة واسم مستخدم فريد (@username) للبحث والإضافة",
                    )
                }

                Spacer(Modifier.height(26.dp))

                if (errorMessage != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = errorMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        errorMessage = null
                        isLoading = true
                        onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = {
                                isLoading = false
                                onAuthSuccess()
                            },
                            onAuthError = { msg ->
                                isLoading = false
                                errorMessage = msg
                            },
                            scope = scope,
                            onAuthCancelled = {
                                isLoading = false
                            },
                        )
                    },
                    enabled = !isLoading && !isCheckingSilent,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldGlow,
                        contentColor = ObsidianBg,
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("google_sign_in_button"),
                ) {
                    if (isLoading || isCheckingSilent) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = ObsidianBg,
                            strokeWidth = 2.5.dp,
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = if (isCheckingSilent) "جاري التحقق من الجلسة..." else "جاري تسجيل الدخول...",
                            fontWeight = FontWeight.Bold,
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.sign_in_google),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FeaturePill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
) {
    Surface(
        color = ObsidianSurfaceHigh,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(EmeraldGlow.copy(alpha = 0.14f)),
            ) {
                Icon(icon, contentDescription = null, tint = EmeraldGlow, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun UsernameSetupScreen(
    isBusy: Boolean,
    usernameAvailable: Boolean?,
    feedbackMessage: String?,
    onCheckUsername: (String) -> Unit,
    onSaveProfile: (username: String, displayName: String, statusText: String?) -> Unit,
    onSignOut: () -> Unit,
) {
    val googleUser = Firebase.auth.currentUser
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf(googleUser?.displayName ?: "") }
    var statusText by remember { mutableStateOf("متاح على CallAI") }

    val normalized = AuthProfileRepository.normalizeUsername(username)
    val formatValid = AuthProfileRepository.isValidUsernameFormat(normalized)

    LaunchedEffect(normalized) {
        if (formatValid) {
            onCheckUsername(normalized)
        }
    }

    Scaffold(containerColor = ObsidianBg) { innerPadding ->
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState()),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 520.dp)
                    .padding(24.dp),
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(EmeraldGlow, CyanSpark))),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Groups,
                        contentDescription = null,
                        tint = ObsidianBg,
                        modifier = Modifier.size(36.dp),
                    )
                }

                Spacer(Modifier.height(18.dp))
                Text(
                    text = stringResource(R.string.setup_username_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = googleUser?.email ?: "",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanSpark,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.setup_username_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )

                Spacer(Modifier.height(22.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(24) },
                    label = { Text("اسم المستخدم (@username)") },
                    placeholder = { Text("مثال: ahmed_ai") },
                    leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                    trailingIcon = {
                        when {
                            formatValid && usernameAvailable == true ->
                                Icon(Icons.Filled.CheckCircle, contentDescription = "متاح", tint = EmeraldGlow)
                            formatValid && usernameAvailable == false ->
                                Icon(Icons.Filled.ErrorOutline, contentDescription = "محجوز", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                    supportingText = {
                        val msg = when {
                            username.isEmpty() -> "3 إلى 24 حرفاً إنجليزياً صغيراً أو أرقاماً أو _"
                            !formatValid -> "استخدم أحرفاً إنجليزية صغيرة وأرقاماً و _ فقط (3-24)"
                            usernameAvailable == true -> "اسم المستخدم @$normalized متاح!"
                            usernameAvailable == false -> "اسم المستخدم @$normalized محجوز لمستخدم آخر"
                            else -> "جاري التحقق من التوفر..."
                        }
                        Text(msg)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_setup_input"),
                )

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it.take(80) },
                    label = { Text("الاسم المعروض") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("display_name_input"),
                )

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = statusText,
                    onValueChange = { statusText = it.take(160) },
                    label = { Text("الحالة / نبذة قصيرة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                if (!feedbackMessage.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = feedbackMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }

                Spacer(Modifier.height(22.dp))

                Button(
                    onClick = { onSaveProfile(normalized, displayName, statusText) },
                    enabled = !isBusy && formatValid && usernameAvailable != false && displayName.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGlow, contentColor = ObsidianBg),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("complete_profile_button"),
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = ObsidianBg, strokeWidth = 2.dp)
                    } else {
                        Text("تأكيد وبدء الاستخدام", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(12.dp))
                androidx.compose.material3.TextButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("setup_sign_out_button"),
                ) {
                    Text("تبديل حساب Google", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
