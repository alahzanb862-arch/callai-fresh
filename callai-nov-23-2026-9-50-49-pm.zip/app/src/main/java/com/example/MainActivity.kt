package com.example

import android.Manifest
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.appcheck.configureAppCheck
import com.example.data.ai.GeminiAssistantRepository
import com.example.data.model.Conversation
import com.example.data.model.PrivateUser
import com.example.data.model.UiState
import com.example.data.repository.AuthProfileRepository
import com.example.data.repository.CallRepository
import com.example.data.repository.MessagingRepository
import com.example.data.repository.authStateFlow
import com.example.data.repository.signOut
import com.example.notifications.CallNotificationManager
import com.example.ui.components.IncomingCallBanner
import com.example.ui.screens.ActiveCallScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.MainTabScreen
import com.example.ui.screens.UsernameSetupScreen
import com.example.ui.theme.CallAITheme
import com.example.ui.theme.EmeraldGlow
import com.example.viewmodel.ActiveCallViewModel
import com.example.viewmodel.ChatDetailViewModel
import com.example.viewmodel.MainSessionViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val ROUTE_HOME = "home"
private const val ROUTE_CHAT = "chat/{conversationId}"
private const val ROUTE_CALL = "call/{callId}"

class MainActivity : ComponentActivity() {
    private val _pendingNavIntent = MutableStateFlow<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI or ViewModels.
        configureAppCheck(this, intent)
        _pendingNavIntent.value = intent

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent {
            val navIntent by _pendingNavIntent.asStateFlow().collectAsStateWithLifecycle()
            CallAITheme {
                CallAIRoot(
                    pendingIntent = navIntent,
                    onConsumeIntent = { _pendingNavIntent.value = null },
                )
            }
        }

        lifecycleScope.launch(Dispatchers.IO) {
            CallNotificationManager.ensureChannels(applicationContext)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        _pendingNavIntent.value = intent
    }
}

@Composable
fun CallAIRoot(
    auth: FirebaseAuth = Firebase.auth,
    pendingIntent: Intent? = null,
    onConsumeIntent: () -> Unit = {},
) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = { /* AuthStateListener updates currentUser */ })
    } else {
        key(user.uid) {
            AuthenticatedApp(
                currentUserId = user.uid,
                pendingIntent = pendingIntent,
                onConsumeIntent = onConsumeIntent,
            )
        }
    }
}

@Composable
private fun AuthenticatedApp(
    currentUserId: String,
    pendingIntent: Intent?,
    onConsumeIntent: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val notifPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* Permission result handled gracefully via CallNotificationManager */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !CallNotificationManager.hasNotificationPermission(context)
        ) {
            withFrameNanos { }
            delay(350)
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val sessionViewModel: MainSessionViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                val authRepo = AuthProfileRepository(db)
                val msgRepo = MessagingRepository(db, authRepo)
                val callRepo = CallRepository(db)
                MainSessionViewModel(authRepo, msgRepo, callRepo, currentUserId)
            }
        },
    )

    val myProfileState by sessionViewModel.myProfileState.collectAsStateWithLifecycle()
    val contactsState by sessionViewModel.contactsState.collectAsStateWithLifecycle()
    val conversationsState by sessionViewModel.conversationsState.collectAsStateWithLifecycle()
    val callsState by sessionViewModel.callsState.collectAsStateWithLifecycle()
    val peerProfiles by sessionViewModel.peerProfiles.collectAsStateWithLifecycle()
    val incomingCall by sessionViewModel.incomingCall.collectAsStateWithLifecycle()
    val isBusy by sessionViewModel.isBusy.collectAsStateWithLifecycle()
    val feedbackMessage by sessionViewModel.feedbackMessage.collectAsStateWithLifecycle()
    val usernameAvailable by sessionViewModel.usernameAvailable.collectAsStateWithLifecycle()
    val searchedProfile by sessionViewModel.searchedProfile.collectAsStateWithLifecycle()

    val performSignOut: () -> Unit = {
        signOut(credentialManager, scope)
    }

    when (val profileState = myProfileState) {
        is UiState.Loading -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = EmeraldGlow)
            }
        }
        is UiState.Error -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(profileState.message, color = MaterialTheme.colorScheme.error)
            }
        }
        is UiState.Success -> {
            val myProfile = profileState.data
            if (myProfile == null) {
                UsernameSetupScreen(
                    isBusy = isBusy,
                    usernameAvailable = usernameAvailable,
                    feedbackMessage = feedbackMessage,
                    onCheckUsername = sessionViewModel::checkUsername,
                    onSaveProfile = sessionViewModel::saveUsernameAndProfile,
                    onSignOut = performSignOut,
                )
            } else {
                AuthenticatedNavGraph(
                    myProfile = myProfile,
                    sessionViewModel = sessionViewModel,
                    contactsState = contactsState,
                    conversationsState = conversationsState,
                    callsState = callsState,
                    peerProfiles = peerProfiles,
                    incomingCall = incomingCall,
                    isBusy = isBusy,
                    feedbackMessage = feedbackMessage,
                    searchedProfile = searchedProfile,
                    pendingIntent = pendingIntent,
                    onConsumeIntent = onConsumeIntent,
                    onRequestNotificationPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onSignOut = performSignOut,
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedNavGraph(
    myProfile: PrivateUser,
    sessionViewModel: MainSessionViewModel,
    contactsState: UiState<List<com.example.data.model.Contact>>,
    conversationsState: UiState<List<Conversation>>,
    callsState: UiState<List<com.example.data.model.CallSession>>,
    peerProfiles: Map<String, com.example.data.model.PublicProfile>,
    incomingCall: com.example.data.model.CallSession?,
    isBusy: Boolean,
    feedbackMessage: String?,
    searchedProfile: com.example.data.model.PublicProfile?,
    pendingIntent: Intent?,
    onConsumeIntent: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onSignOut: () -> Unit,
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val contacts = (contactsState as? UiState.Success)?.data ?: emptyList()
    val conversations = (conversationsState as? UiState.Success)?.data ?: emptyList()

    // Handle deep-links from notification taps
    LaunchedEffect(pendingIntent) {
        val intent = pendingIntent ?: return@LaunchedEffect
        val targetCallId = intent.getStringExtra(CallNotificationManager.EXTRA_CALL_ID)
        val targetConvId = intent.getStringExtra(CallNotificationManager.EXTRA_CONVERSATION_ID)
        if (!targetCallId.isNullOrBlank()) {
            CallNotificationManager.cancelIncomingCallNotification(context, targetCallId)
            navController.navigate("call/$targetCallId")
            onConsumeIntent()
        } else if (!targetConvId.isNullOrBlank()) {
            navController.navigate("chat/$targetConvId")
            onConsumeIntent()
        }
    }

    // Trigger system notification for incoming ringing calls
    var lastNotifiedCallId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(incomingCall) {
        val currentRoute = navController.currentBackStackEntry?.destination?.route
        if (incomingCall != null && currentRoute != ROUTE_CALL) {
            if (lastNotifiedCallId != incomingCall.id) {
                CallNotificationManager.showIncomingCallNotification(context, incomingCall)
                lastNotifiedCallId = incomingCall.id
            }
        } else if (lastNotifiedCallId != null) {
            CallNotificationManager.cancelIncomingCallNotification(context, lastNotifiedCallId!!)
            lastNotifiedCallId = null
        }
    }

    // Trigger system notification when new messages arrive in other conversations
    var initializedMessageBaseline by remember { mutableStateOf(false) }
    val seenMessageTimes = remember { mutableStateMapOf<String, Long>() }
    LaunchedEffect(conversationsState) {
        val convList = (conversationsState as? UiState.Success)?.data ?: return@LaunchedEffect
        if (!initializedMessageBaseline) {
            convList.forEach { c ->
                val ts = (c.lastMessageAt ?: c.updatedAt)?.let { it.seconds * 1000L + it.nanoseconds / 1_000_000L } ?: 0L
                seenMessageTimes[c.id] = ts
            }
            initializedMessageBaseline = true
            return@LaunchedEffect
        }
        val activeConvId = navController.currentBackStackEntry?.arguments?.getString("conversationId")
        val mySenderName = myProfile.displayName.ifBlank { myProfile.username }
        convList.forEach { c ->
            val ts = (c.lastMessageAt ?: c.updatedAt)?.let { it.seconds * 1000L + it.nanoseconds / 1_000_000L } ?: 0L
            val prev = seenMessageTimes[c.id] ?: 0L
            if (ts > prev) {
                seenMessageTimes[c.id] = ts
                val sender = c.lastMessageSenderName.orEmpty()
                val body = c.lastMessageText.orEmpty()
                if (body.isNotBlank() && sender != mySenderName && activeConvId != c.id) {
                    val title = sessionViewModel.resolveDirectTitle(c, contacts)
                    CallNotificationManager.showNewMessageNotification(
                        context = context,
                        conversationId = c.id,
                        chatTitle = title,
                        senderName = sender.ifBlank { title },
                        messageText = body,
                    )
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = ROUTE_HOME,
            modifier = Modifier.fillMaxSize(),
        ) {
            composable(ROUTE_HOME) {
                MainTabScreen(
                    myProfile = myProfile,
                    contactsState = contactsState,
                    conversationsState = conversationsState,
                    callsState = callsState,
                    peerProfiles = peerProfiles,
                    searchedProfile = searchedProfile,
                    isBusy = isBusy,
                    feedbackMessage = feedbackMessage,
                    onClearFeedback = sessionViewModel::clearFeedback,
                    onLookupUsername = sessionViewModel::lookupUsername,
                    onClearSearchedProfile = sessionViewModel::clearSearchedProfile,
                    onAddContact = { username, nickname, onDone ->
                        sessionViewModel.addContactByUsername(username, nickname, onDone)
                    },
                    onUpdateContactNickname = sessionViewModel::updateContactNickname,
                    onDeleteContact = sessionViewModel::deleteContact,
                    onOpenConversation = { convId ->
                        navController.navigate("chat/$convId")
                    },
                    onOpenDirectChat = { targetUid, targetName ->
                        sessionViewModel.openDirectChat(targetUid, targetName) { convId ->
                            navController.navigate("chat/$convId")
                        }
                    },
                    onCreateGroup = { title, desc, memberUids ->
                        sessionViewModel.createGroup(title, desc, memberUids) { convId ->
                            navController.navigate("chat/$convId")
                        }
                    },
                    onStartDirectCall = { targetUid, targetName, mode ->
                        sessionViewModel.startDirectCall(targetUid, targetName, mode) { callId ->
                            navController.navigate("call/$callId")
                        }
                    },
                    onStartGroupCall = { conv, mode ->
                        sessionViewModel.startGroupCall(conv, mode) { callId ->
                            navController.navigate("call/$callId")
                        }
                    },
                    onUpdateProfile = sessionViewModel::updateProfileInfo,
                    onRequestNotificationPermission = onRequestNotificationPermission,
                    onSignOut = onSignOut,
                    resolveDirectTitle = sessionViewModel::resolveDirectTitle,
                )
            }

            composable(
                route = ROUTE_CHAT,
                arguments = listOf(navArgument("conversationId") { type = NavType.StringType }),
            ) { backStackEntry ->
                val convId = backStackEntry.arguments?.getString("conversationId").orEmpty()
                val conversation = conversations.firstOrNull { it.id == convId }
                if (conversation == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EmeraldGlow)
                    }
                } else {
                    val chatVm: ChatDetailViewModel = viewModel(
                        key = "${myProfile.uid}_chat_$convId",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                                val msgRepo = MessagingRepository(db, AuthProfileRepository(db))
                                ChatDetailViewModel(
                                    messagingRepo = msgRepo,
                                    aiRepo = GeminiAssistantRepository(),
                                    conversationId = convId,
                                    currentUserId = myProfile.uid,
                                )
                            }
                        },
                    )
                    val title = sessionViewModel.resolveDirectTitle(conversation, contacts)
                    ChatDetailScreen(
                        conversation = conversation,
                        chatTitle = title,
                        myProfile = myProfile,
                        contacts = contacts,
                        viewModel = chatVm,
                        onBack = { navController.popBackStack() },
                        onStartCall = { mode ->
                            if (conversation.conversationType == com.example.data.model.ConversationType.GROUP) {
                                sessionViewModel.startGroupCall(conversation, mode) { callId ->
                                    navController.navigate("call/$callId")
                                }
                            } else {
                                val targetUid = conversation.memberUids.firstOrNull { it != myProfile.uid }
                                if (targetUid != null) {
                                    sessionViewModel.startDirectCall(targetUid, title, mode, conversation.id) { callId ->
                                        navController.navigate("call/$callId")
                                    }
                                }
                            }
                        },
                    )
                }
            }

            composable(
                route = ROUTE_CALL,
                arguments = listOf(navArgument("callId") { type = NavType.StringType }),
            ) { backStackEntry ->
                val callId = backStackEntry.arguments?.getString("callId").orEmpty()
                val callVm: ActiveCallViewModel = viewModel(
                    key = "${myProfile.uid}_call_$callId",
                    factory = viewModelFactory {
                        initializer {
                            val app = checkNotNull(this[APPLICATION_KEY])
                            val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                            ActiveCallViewModel(
                                callRepo = CallRepository(db),
                                aiRepo = GeminiAssistantRepository(),
                                callId = callId,
                                currentUserId = myProfile.uid,
                            )
                        }
                    },
                )
                ActiveCallScreen(
                    myProfile = myProfile,
                    viewModel = callVm,
                    onCallClosed = { navController.popBackStack() },
                )
            }
        }

        // Global Incoming Call Banner overlay
        incomingCall?.let { call ->
            val currentRoute = navController.currentBackStackEntry?.destination?.route
            if (currentRoute != ROUTE_CALL) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .safeDrawingPadding(),
                ) {
                    IncomingCallBanner(
                        call = call,
                        onAccept = {
                            sessionViewModel.acceptIncomingCall(call.id) { acceptedId ->
                                navController.navigate("call/$acceptedId")
                            }
                        },
                        onDecline = {
                            sessionViewModel.declineIncomingCall(call.id)
                        },
                    )
                }
            }
        }
    }
}
