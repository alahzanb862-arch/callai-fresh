package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.CallEvent
import com.example.data.model.CallEventType
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.PrivateUser
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CallRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id),
        ),
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeMyCalls(userId: String): Flow<List<CallSession>> = flow {
        val path = "calls"
        emitAll(
            db.collection("calls")
                .whereArrayContains("participantUids", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CallSession::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                },
        )
    }

    fun observeCall(callId: String, userId: String): Flow<CallSession?> = flow {
        val path = "calls/$callId"
        emitAll(
            db.collection("calls").document(callId)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(
                        CallSession::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw error
                },
        )
    }

    fun observeCallEvents(callId: String, userId: String): Flow<List<CallEvent>> = flow {
        val path = "calls/$callId/events"
        emitAll(
            db.collection("calls").document(callId)
                .collection("events")
                .whereArrayContains("participantUids", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CallEvent::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    ).sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                },
        )
    }

    suspend fun startCall(
        caller: PrivateUser,
        calleeName: String,
        participantUids: List<String>,
        callMode: CallMode,
        conversationId: String? = null,
    ): Result<CallSession> {
        val callRef = db.collection("calls").document()
        return try {
            val uid = requireUserId()
            check(uid == caller.uid)
            val participants = (listOf(uid) + participantUids).distinct().take(10)
            val callerName = caller.displayName.ifBlank { caller.username }.take(80)
            val payload = mutableMapOf<String, Any>(
                "callerId" to uid,
                "callerName" to callerName,
                "callerUsername" to caller.username,
                "calleeName" to calleeName.trim().take(80).ifEmpty { "صديق" },
                "participantUids" to participants,
                "callMode" to callMode.wireValue,
                "status" to CallStatus.RINGING.wireValue,
                "aiActive" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            conversationId?.takeIf { it.isNotBlank() }?.let { payload["conversationId"] = it.take(128) }

            callRef.set(payload).await()
            Result.success(
                CallSession(
                    id = callRef.id,
                    conversationId = conversationId,
                    callerId = uid,
                    callerName = callerName,
                    callerUsername = caller.username,
                    calleeName = calleeName,
                    participantUids = participants,
                    callMode = callMode.wireValue,
                    status = CallStatus.RINGING.wireValue,
                    aiActive = false,
                ),
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, callRef.path)
            Result.failure(e)
        }
    }

    suspend fun acceptCall(callId: String): Result<Unit> =
        updateCallStatus(callId, CallStatus.ACTIVE, includeEndedAt = false)

    suspend fun declineCall(callId: String): Result<Unit> =
        updateCallStatus(callId, CallStatus.DECLINED, includeEndedAt = true)

    suspend fun endCall(callId: String): Result<Unit> =
        updateCallStatus(callId, CallStatus.ENDED, includeEndedAt = true)

    private suspend fun updateCallStatus(
        callId: String,
        status: CallStatus,
        includeEndedAt: Boolean,
    ): Result<Unit> {
        val path = "calls/$callId"
        return try {
            requireUserId()
            val updates = mutableMapOf<String, Any>(
                "status" to status.wireValue,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (includeEndedAt) {
                updates["endedAt"] = FieldValue.serverTimestamp()
            }
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleCallMode(callId: String, mode: CallMode): Result<Unit> {
        val path = "calls/$callId"
        return try {
            requireUserId()
            db.collection("calls").document(callId)
                .update(
                    mapOf(
                        "callMode" to mode.wireValue,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun postCallEvent(
        callId: String,
        participantUids: List<String>,
        sender: PrivateUser,
        eventType: CallEventType,
        content: String,
    ): Result<Unit> {
        val cleanContent = content.trim().take(4000)
        if (cleanContent.isEmpty()) return Result.success(Unit)
        val evtRef = db.collection("calls").document(callId).collection("events").document()
        return try {
            val uid = requireUserId()
            check(uid == sender.uid)
            val senderName = sender.displayName.ifBlank { sender.username }.take(80)
            evtRef.set(
                mapOf(
                    "callId" to callId,
                    "senderId" to uid,
                    "senderName" to senderName,
                    "eventType" to eventType.wireValue,
                    "content" to cleanContent,
                    "participantUids" to participantUids.take(10),
                    "createdAt" to FieldValue.serverTimestamp(),
                ),
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, evtRef.path)
            Result.failure(e)
        }
    }

    suspend fun shareAiAnswerInCall(
        callId: String,
        participantUids: List<String>,
        sender: PrivateUser,
        prompt: String,
        answer: String,
    ): Result<Unit> {
        val callRef = db.collection("calls").document(callId)
        val evtRef = callRef.collection("events").document()
        return try {
            val uid = requireUserId()
            check(uid == sender.uid)
            val senderName = sender.displayName.ifBlank { sender.username }.take(80)
            val cleanPrompt = prompt.trim().take(1000)
            val cleanAnswer = answer.trim().take(4000)

            val batch = db.batch()
            batch.update(
                callRef,
                mapOf(
                    "aiActive" to true,
                    "lastAiPrompt" to cleanPrompt,
                    "lastAiAnswer" to cleanAnswer,
                    "lastAiByName" to senderName,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            )
            batch.set(
                evtRef,
                mapOf(
                    "callId" to callId,
                    "senderId" to uid,
                    "senderName" to senderName,
                    "eventType" to CallEventType.AI_ANSWER.wireValue,
                    "content" to "❓ $cleanPrompt\n\n✨ $cleanAnswer".take(4000),
                    "participantUids" to participantUids.take(10),
                    "createdAt" to FieldValue.serverTimestamp(),
                ),
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, callRef.path)
            Result.failure(e)
        }
    }
}
