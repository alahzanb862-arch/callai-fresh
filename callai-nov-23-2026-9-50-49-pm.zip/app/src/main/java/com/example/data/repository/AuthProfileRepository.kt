package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private const val AUTH_TAG = "Auth"

internal fun FirebaseAuth.authStateFlow() = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope,
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onUnauthenticated()
        return
    }
    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()
    scope.launch {
        try {
            val cred = credentialManager.getCredential(context, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {},
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
        return
    }
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()
    scope.launch {
        try {
            val activityContext = context as? Activity ?: context
            val cred = credentialManager.getCredential(activityContext, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onAuthError("نوع بيانات الاعتماد غير مدعوم")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(AUTH_TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e(AUTH_TAG, "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "فشل تسجيل الدخول عبر Google")
        }
    }
}

fun signOut(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {},
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w(AUTH_TAG, "Failed to clear credential state: ${e.message}")
            } finally {
                Firebase.auth.signOut()
                onSignOutComplete()
            }
        }
    }
}

class AuthProfileRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id),
        ),
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeMyProfile(userId: String): Flow<PrivateUser?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        PrivateUser::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw error
                },
        )
    }

    suspend fun isUsernameAvailable(rawUsername: String): Result<Boolean> {
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.success(false)
        }
        val path = "usernames/$normalized"
        return try {
            requireUserId()
            val snap = db.collection("usernames").document(normalized).get().await()
            Result.success(!snap.exists())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun registerUsernameAndProfile(
        rawUsername: String,
        displayName: String,
        statusText: String?,
    ): Result<Unit> {
        val user = auth.currentUser
            ?: return Result.failure(IllegalStateException("يجب تسجيل الدخول أولاً"))
        val uid = user.uid
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.failure(IllegalArgumentException("اسم المستخدم يجب أن يكون 3 إلى 24 حرفاً إنجليزياً صغيراً أو أرقاماً أو _"))
        }
        val cleanName = displayName.trim().take(80)
        if (cleanName.isEmpty()) {
            return Result.failure(IllegalArgumentException("الاسم المعروض مطلوب"))
        }
        val cleanStatus = statusText?.trim()?.take(160)?.takeIf { it.isNotEmpty() }
        val photoUrl = user.photoUrl?.toString()?.take(500)?.takeIf { it.isNotBlank() }
        val email = (user.email ?: "").take(254)

        return try {
            val existingClaim = db.collection("usernames").document(normalized).get().await()
            if (existingClaim.exists() && existingClaim.getString("uid") != uid) {
                return Result.failure(IllegalStateException("اسم المستخدم @$normalized محجوز بالفعل"))
            }

            val batch = db.batch()
            val usernameRef = db.collection("usernames").document(normalized)
            if (!existingClaim.exists()) {
                val claimMap = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to cleanName,
                    "createdAt" to FieldValue.serverTimestamp(),
                )
                if (photoUrl != null) claimMap["photoUrl"] = photoUrl
                batch.set(usernameRef, claimMap)
            }

            val publicRef = db.collection("publicProfiles").document(uid)
            val publicMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "username" to normalized,
                "displayName" to cleanName,
                "online" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (photoUrl != null) publicMap["photoUrl"] = photoUrl
            if (cleanStatus != null) publicMap["statusText"] = cleanStatus
            batch.set(publicRef, publicMap)

            val privateRef = db.collection("users").document(uid)
            val privateMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "email" to email,
                "username" to normalized,
                "displayName" to cleanName,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (photoUrl != null) privateMap["photoUrl"] = photoUrl
            if (cleanStatus != null) privateMap["statusText"] = cleanStatus
            batch.set(privateRef, privateMap)

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun lookupUserByUsername(rawUsername: String): Result<PublicProfile?> {
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.success(null)
        }
        val path = "usernames/$normalized"
        return try {
            requireUserId()
            val claimSnap = db.collection("usernames").document(normalized).get().await()
            if (!claimSnap.exists()) return Result.success(null)
            val targetUid = claimSnap.getString("uid") ?: return Result.success(null)
            getPublicProfile(targetUid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun getPublicProfile(targetUid: String): Result<PublicProfile?> {
        val path = "publicProfiles/$targetUid"
        return try {
            requireUserId()
            val snap = db.collection("publicProfiles").document(targetUid).get().await()
            val profile = snap.toObject(
                PublicProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            )
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfileInfo(displayName: String, statusText: String?, username: String): Result<Unit> {
        val uid = auth.currentUser?.uid
            ?: return Result.failure(IllegalStateException("User not signed in"))
        val cleanName = displayName.trim().take(80)
        if (cleanName.isEmpty()) return Result.failure(IllegalArgumentException("الاسم مطلوب"))
        val cleanStatus = statusText?.trim()?.take(160) ?: ""

        return try {
            val batch = db.batch()
            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "displayName" to cleanName,
                    "statusText" to cleanStatus,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            )
            batch.update(
                db.collection("publicProfiles").document(uid),
                mapOf(
                    "displayName" to cleanName,
                    "statusText" to cleanStatus,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            )
            if (isValidUsernameFormat(username)) {
                batch.update(
                    db.collection("usernames").document(username),
                    mapOf("displayName" to cleanName),
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    companion object {
        private val USERNAME_REGEX = Regex("^[a-z0-9_]{3,24}$")

        fun normalizeUsername(raw: String): String =
            raw.trim().removePrefix("@").lowercase()

        fun isValidUsernameFormat(username: String): Boolean =
            USERNAME_REGEX.matches(username)
    }
}
