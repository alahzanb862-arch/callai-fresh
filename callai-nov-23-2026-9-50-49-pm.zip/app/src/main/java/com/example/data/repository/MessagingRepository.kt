package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.ChatMessage
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.MessageType
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MessagingRepository(
    private val db: FirebaseFirestore,
    private val authProfileRepo: AuthProfileRepository,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id),
        ),
        authProfileRepo = AuthProfileRepository(context),
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    // --- CONTACTS ---

    fun observeContacts(userId: String): Flow<List<Contact>> = flow {
        val path = "users/$userId/contacts"
        emitAll(
            db.collection("users").document(userId).collection("contacts")
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        Contact::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    ).sortedBy { (it.nickname ?: it.displayName).lowercase() }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                },
        )
    }

    suspend fun addContactByUsername(
        userId: String,
        rawUsername: String,
        nickname: String? = null,
    ): Result<Contact> {
        val path = "users/$userId/contacts"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Refusing cross-user write" }

            val profileResult = authProfileRepo.lookupUserByUsername(rawUsername)
            val profile = profileResult.getOrElse { return Result.failure(it) }
                ?: return Result.failure(IllegalStateException("لم يتم العثور على مستخدم بالاسم @${AuthProfileRepository.normalizeUsername(rawUsername)}"))

            if (profile.uid == uid) {
                return Result.failure(IllegalArgumentException("لا يمكنك إضافة نفسك كجهة اتصال"))
            }

            val cleanNickname = nickname?.trim()?.take(80)?.takeIf { it.isNotEmpty() }
            val payload = mutableMapOf<String, Any>(
                "contactUid" to profile.uid,
                "username" to profile.username,
                "displayName" to profile.displayName.take(80),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            profile.photoUrl?.take(500)?.takeIf { it.isNotBlank() }?.let { payload["photoUrl"] = it }
            cleanNickname?.let { payload["nickname"] = it }

            db.collection("users").document(uid)
                .collection("contacts").document(profile.uid)
                .set(payload)
                .await()

            Result.success(
                Contact(
                    id = profile.uid,
                    contactUid = profile.uid,
                    username = profile.username,
                    displayName = profile.displayName,
                    photoUrl = profile.photoUrl,
                    nickname = cleanNickname,
                ),
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateContactNickname(userId: String, contactUid: String, nickname: String): Result<Unit> {
        val path = "users/$userId/contacts/$contactUid"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val clean = nickname.trim().take(80)
            db.collection("users").document(uid)
                .collection("contacts").document(contactUid)
                .update(
                    mapOf(
                        "nickname" to clean,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteContact(userId: String, contactUid: String): Result<Unit> {
        val path = "users/$userId/contacts/$contactUid"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            db.collection("users").document(uid)
                .collection("contacts").document(contactUid)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- CONVERSATIONS & GROUPS ---

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        val path = "conversations"
        emitAll(
            db.collection("conversations")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        Conversation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    ).sortedByDescending {
                        (it.lastMessageAt ?: it.updatedAt ?: it.createdAt)?.seconds ?: 0L
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                },
        )
    }

    suspend fun getOrCreateDirectConversation(
        myProfile: PrivateUser,
        targetUid: String,
        targetDisplayName: String,
    ): Result<Conversation> {
        val sorted = listOf(myProfile.uid, targetUid).sorted()
        val convId = "dm_${sorted[0]}_${sorted[1]}".take(128)
        val path = "conversations/$convId"
        return try {
            val uid = requireUserId()
            check(uid == myProfile.uid)
            val docRef = db.collection("conversations").document(convId)
            val existing = try {
                docRef.get().await()
            } catch (_: FirebaseFirestoreException) {
                null
            }
            if (existing != null && existing.exists()) {
                val conv = existing.toObject(
                    Conversation::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
                if (conv != null) return Result.success(conv)
            }

            val payload = mapOf(
                "type" to ConversationType.DIRECT.wireValue,
                "title" to targetDisplayName.take(80),
                "createdBy" to uid,
                "memberUids" to sorted,
                "adminUids" to sorted,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
            Result.success(
                Conversation(
                    id = convId,
                    type = ConversationType.DIRECT.wireValue,
                    title = targetDisplayName,
                    createdBy = uid,
                    memberUids = sorted,
                    adminUids = sorted,
                ),
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createGroupConversation(
        myProfile: PrivateUser,
        title: String,
        description: String?,
        invitedMemberUids: List<String>,
    ): Result<Conversation> {
        val cleanTitle = title.trim().take(80)
        if (cleanTitle.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المجموعة مطلوب"))
        }
        val docRef = db.collection("conversations").document()
        val path = docRef.path
        return try {
            val uid = requireUserId()
            val members = (listOf(uid) + invitedMemberUids).distinct().take(25)
            val admins = listOf(uid)
            val cleanDesc = description?.trim()?.take(240)?.takeIf { it.isNotEmpty() }

            val payload = mutableMapOf<String, Any>(
                "type" to ConversationType.GROUP.wireValue,
                "title" to cleanTitle,
                "createdBy" to uid,
                "memberUids" to members,
                "adminUids" to admins,
                "lastMessageText" to "تم إنشاء المجموعة بواسطة ${myProfile.displayName}".take(500),
                "lastMessageSenderName" to myProfile.displayName.take(80),
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            cleanDesc?.let { payload["description"] = it }

            docRef.set(payload).await()
            Result.success(
                Conversation(
                    id = docRef.id,
                    type = ConversationType.GROUP.wireValue,
                    title = cleanTitle,
                    description = cleanDesc,
                    createdBy = uid,
                    memberUids = members,
                    adminUids = admins,
                ),
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateGroupInfo(
        conversationId: String,
        title: String,
        description: String?,
    ): Result<Unit> {
        val cleanTitle = title.trim().take(80)
        if (cleanTitle.isEmpty()) return Result.failure(IllegalArgumentException("اسم المجموعة مطلوب"))
        val path = "conversations/$conversationId"
        return try {
            requireUserId()
            val cleanDesc = description?.trim()?.take(240) ?: ""
            db.collection("conversations").document(conversationId)
                .update(
                    mapOf(
                        "title" to cleanTitle,
                        "description" to cleanDesc,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addMemberToGroup(
        conversationId: String,
        currentMembers: List<String>,
        newMemberUid: String,
    ): Result<Unit> {
        val path = "conversations/$conversationId"
        return try {
            requireUserId()
            val updated = (currentMembers + newMemberUid).distinct().take(25)
            db.collection("conversations").document(conversationId)
                .update(
                    mapOf(
                        "memberUids" to updated,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeMemberFromGroup(
        conversationId: String,
        currentMembers: List<String>,
        currentAdmins: List<String>,
        targetUid: String,
    ): Result<Unit> {
        val path = "conversations/$conversationId"
        return try {
            requireUserId()
            val updatedMembers = currentMembers.filterNot { it == targetUid }
            val updatedAdmins = currentAdmins.filterNot { it == targetUid }
            if (updatedMembers.isEmpty()) {
                return Result.failure(IllegalStateException("لا يمكن إزالة آخر عضو في المجموعة"))
            }
            db.collection("conversations").document(conversationId)
                .update(
                    mapOf(
                        "memberUids" to updatedMembers,
                        "adminUids" to updatedAdmins.ifEmpty { listOf(updatedMembers.first()) },
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- MESSAGES ---

    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> = flow {
        val path = "conversations/$conversationId/messages"
        emitAll(
            db.collection("conversations").document(conversationId)
                .collection("messages")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    ).sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                },
        )
    }

    suspend fun sendMessage(
        conversation: Conversation,
        sender: PrivateUser,
        rawText: String,
        messageType: MessageType = MessageType.TEXT,
    ): Result<Unit> {
        val cleanText = rawText.trim().take(4000)
        if (cleanText.isEmpty()) {
            return Result.failure(IllegalArgumentException("الرسالة فارغة"))
        }
        val convRef = db.collection("conversations").document(conversation.id)
        val msgRef = convRef.collection("messages").document()
        return try {
            val uid = requireUserId()
            check(uid == sender.uid)
            val senderDisplay = sender.displayName.ifBlank { sender.username }.take(80)

            val msgPayload = mapOf(
                "conversationId" to conversation.id,
                "senderId" to uid,
                "senderName" to senderDisplay,
                "text" to cleanText,
                "messageType" to messageType.wireValue,
                "memberUids" to conversation.memberUids.take(25),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            val previewPayload = mapOf(
                "lastMessageText" to cleanText.take(500),
                "lastMessageSenderName" to senderDisplay,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )

            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            batch.update(convRef, previewPayload)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            Result.failure(e)
        }
    }

    suspend fun resolvePeerProfiles(memberUids: List<String>, myUid: String): List<PublicProfile> {
        return memberUids.filter { it != myUid }.mapNotNull { uid ->
            authProfileRepo.getPublicProfile(uid).getOrNull()
        }
    }
}
